package com.example.app_trabajo_de_titulo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
