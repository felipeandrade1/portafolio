import 'package:app_trabajo_de_titulo/pages/login_page.dart';
import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
// import 'package:shared_preferences/shared_preferences.dart';

class RegistrarUsuarioPage extends StatefulWidget {
  RegistrarUsuarioPage({Key key}) : super(key: key);

  @override
  _RegistrarUsuarioPageState createState() => _RegistrarUsuarioPageState();
}

class _RegistrarUsuarioPageState extends State<RegistrarUsuarioPage> {
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController passwordCtrl = TextEditingController();
  TextEditingController password2Ctrl = TextEditingController();
  TextEditingController nombreCtrl = TextEditingController();
  TextEditingController apellidoMaternoCtrl = TextEditingController();
  TextEditingController apellidoPaternoCtrl = TextEditingController();

  TextEditingController fechaNacimientoCtrl = new TextEditingController();
  TextEditingController celularCtrl = TextEditingController();
  TextEditingController profesionCtrl = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  final _emailRegex =
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";
  var _sexo = ['Masculino', 'Femenino', 'Otro', 'Prefiero no Contestar'];
  var _sexoItemSelected = 'Prefiero no Contestar';
  var _perfil = [
    'Entrenador',
    'Velocista',
  ];
  var _perfilItemSelected = 'Entrenador';

  String mensajeLogin = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registrar Usuario'),
      ),
      body: Center(
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              _txtEmail(),
              _txtPassword(),
              _txtPassword2(),
              _txtNombre(),
              _txtApellidoPaterno(),
              _txtApellidoMaterno(),
              _txtFechaNacimiento(context),
              _txtNumeroCelular(),
              _txtSexo(),
              _txtPerfil(),
              _txtProfesion(),
              Container(
                  margin: EdgeInsets.only(top: 10.0),
                  alignment: Alignment.center,
                  child: Text(
                    mensajeLogin,
                    style: TextStyle(color: Colors.red),
                  )),
              _btnRegistrar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _txtEmail() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: emailCtrl,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          labelText: 'Correo',
          suffixIcon: Icon(
            FontAwesomeIcons.envelope,
          ),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'Indique Correo';
          }
          if (!RegExp(_emailRegex).hasMatch(value)) {
            return 'Correo no válido';
          }
          return null;
        },
      ),
    );
  }

  Widget _txtPassword() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: passwordCtrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Contraseña',
          suffixIcon: Icon(FontAwesomeIcons.key),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          if (value.length < 8) {
            return 'La contraseña debe tener mínimo 8 caracteres';
          }

          return null;
        },
      ),
    );
  }

  Widget _txtPassword2() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: password2Ctrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Repetir Contraseña',
          suffixIcon: Icon(FontAwesomeIcons.key),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          if (value != passwordCtrl.text) {
            return 'Las contraseñas no coinciden';
          }

          return null;
        },
      ),
    );
  }

  Widget _txtNombre() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: nombreCtrl,
        keyboardType: TextInputType.name,
        decoration: InputDecoration(
          labelText: 'Nombre',
          suffixIcon: Icon(FontAwesomeIcons.user),
        ),
      ),
    );
  }

  Widget _txtApellidoPaterno() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: apellidoPaternoCtrl,
        decoration: InputDecoration(
          labelText: 'Apellido Paterno',
          suffixIcon: Icon(FontAwesomeIcons.idCard),
        ),
      ),
    );
  }

  Widget _txtApellidoMaterno() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: apellidoMaternoCtrl,
        decoration: InputDecoration(
          labelText: 'Apellido Materno',
          suffixIcon: Icon(FontAwesomeIcons.idCard),
        ),
      ),
    );
  }

  Widget _txtFechaNacimiento(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        enableInteractiveSelection: false,
        controller: fechaNacimientoCtrl,
        decoration: InputDecoration(
          hintText: 'Fecha Nacimiento',
          labelText: 'Fecha Nacimiento',
          suffixIcon: Icon(FontAwesomeIcons.calendarDay),
        ),
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
          _selectDate(context);
        },
      ),
    );
  }

  _selectDate(BuildContext context) async {
    DateTime picked = await showDatePicker(
      context: context,
      initialDate: new DateTime.now(),
      firstDate: new DateTime(2018),
      lastDate: new DateTime.now(),
      locale: Locale('es', 'ES'),
    );

    if (picked != null) {
      setState(() {
        // _fecha = picked.toString();
        fechaNacimientoCtrl.text = DateFormat('dd-MM-yyyy').format(picked);
      });
    }
  }

  Widget _txtNumeroCelular() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: celularCtrl,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          labelText: 'Numero de Celular(+56)',
          suffixIcon: Icon(FontAwesomeIcons.phone),
        ),
      ),
    );
  }

  Widget _txtSexo() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: DropdownButton<String>(
        isExpanded: true,
        hint: Text('Sexo'),
        items: _sexo.map((String dropDownStringItem) {
          return DropdownMenuItem(
            value: dropDownStringItem,
            child: Text(dropDownStringItem),
          );
        }).toList(),
        onChanged: (valueSelect) {
          setState(() {
            this._sexoItemSelected = valueSelect;
          });
        },
        value: _sexoItemSelected,
      ),
    );
  }

  Widget _txtPerfil() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: DropdownButton<String>(
        isExpanded: true,
        hint: Text('Perfil'),
        items: _perfil.map((String dropDownStringItem) {
          return DropdownMenuItem(
            value: dropDownStringItem,
            child: Text(dropDownStringItem),
          );
        }).toList(),
        onChanged: (valueSelect) {
          setState(() {
            this._perfilItemSelected = valueSelect;
          });
        },
        value: _perfilItemSelected,
      ),
    );
  }

  Widget _txtProfesion() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: profesionCtrl,
        decoration: InputDecoration(
          labelText: 'Profesión',
          suffixIcon: Icon(FontAwesomeIcons.userTie),
        ),
      ),
    );
  }

  Widget _btnRegistrar() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: ElevatedButton(
          child: Text('Registrar Usuario'),
          onPressed: () {
            if (_formKey.currentState.validate()) {
              FocusScope.of(context).unfocus();

              // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              //     backgroundColor: ThemeData().primaryColor,
              //     content: Text('Processing Data')));
              _registrarNuevoUsuario();
            }
          },
        ),
      ),
    );
  }

  _registrarNuevoUsuario() async {
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var velocistasService = new VelocistasService();
    var respuesta = await velocistasService.usuarioAgregar(
      emailCtrl.text.trim().toLowerCase(),
      passwordCtrl.text.trim(),
      nombreCtrl.text.trim(),
      apellidoPaternoCtrl.text.trim(),
      apellidoMaternoCtrl.text.trim(),
      fechaNacimientoCtrl.text.trim(),
      celularCtrl.text.trim(),
      _sexoItemSelected.trim(),
      _perfilItemSelected.trim(),
      profesionCtrl.text.trim(),
    );
    // return print(respuesta.statusCode);

    if (respuesta == null) {
      setState(() {
        mensajeLogin = 'Error de conexión';
      });
    } else if (respuesta.statusCode != 200) {
      setState(() {
        mensajeLogin = 'Error: ' + respuesta.statusCode.toString();
      });
    } else if (respuesta.statusCode == 200) {
      setState(() {
        if (_perfilItemSelected.trim() == 'Velocista') {
          final route = MaterialPageRoute(builder: (context) {
            return;
          });
          Navigator.pushReplacement(context, route);
        } else {
          final route = MaterialPageRoute(builder: (context) {
            return LoginPage();
          });
          Navigator.pushReplacement(context, route);
        }
      });
    }
    {
      // sharedPreferences.setString('token', respuesta['access_token']);
      // final route = MaterialPageRoute(builder: (context) {
      //   return HomePage();
      // });
      // Navigator.pushReplacement(context, route);
    }
  }

  //  Widget _progressIndicator() {
  //   return isLoading? Center(
  //           child: CircularProgressIndicator(),
  //         )
  //       : Text('');
  // }
}
