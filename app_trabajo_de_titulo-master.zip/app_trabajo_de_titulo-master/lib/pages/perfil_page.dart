import 'package:app_trabajo_de_titulo/pages/eliminar_cuenta_page.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class PerfilPage extends StatefulWidget {
  PerfilPage({Key key}) : super(key: key);

  @override
  _PerfilPageState createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  TextEditingController passwordCtrl = TextEditingController();
  TextEditingController passwordNuevaCtrl = TextEditingController();
  TextEditingController passwordNueva2Ctrl = TextEditingController();
  TextEditingController nombreCtrl = TextEditingController();
  TextEditingController apellidoPaternoCtrl = TextEditingController();
  TextEditingController apellidoMaternoCtrl = TextEditingController();

  TextEditingController fechaNacimientoCtrl = new TextEditingController();
  TextEditingController celularCtrl = TextEditingController();
  TextEditingController profesionCtrl = TextEditingController();

  var _sexo = ['Masculino', 'Femenino', 'Otro', 'Prefiero no Contestar'];
  var _sexoItemSelected = 'Prefiero no Contestar';
  var _perfil = [
    'Entrenador',
    'Velocista',
  ];
  var _perfilItemSelected = 'Entrenador';

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi Perfil'),
      ),
      body: ListView(
        children: [
          Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 200,
                width: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage('assets/images/user-masculino.png'),
                  ),
                  border: Border.all(
                    width: 2.0,
                    color: ThemeData().primaryColor,
                  ),
                ),
              ),
            ),
          ),
          _txtNombre(),
          _txtApellidoPaterno(),
          _txtApellidoMaterno(),
          _txtPassword(),
          _txtPasswordNueva(),
          _txtPassword2(),
          _txtFechaNacimiento(context),
          _txtNumeroCelular(),
          _txtSexo(),
          _txtPerfil(),
          _txtProfesion(),
          Container(
            child: TextButton(
              child: Text(
                'Eliminar Cuenta',
                style: TextStyle(decoration: TextDecoration.underline),
              ),
              onPressed: () {
                final route = MaterialPageRoute(
                  builder: (context) => EliminarCuentaPage(),
                );
                Navigator.push(context, route);
              },
            ),
          ),
          _btnGuardar(),
        ],
      ),
    );
  }

  Widget _txtPassword() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: passwordCtrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Contraseña Actual',
          suffixIcon: Icon(FontAwesomeIcons.key),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          if (value.length < 8) {
            return 'La contraseña debe tener mínimo 8 caracteres';
          }

          return null;
        },
      ),
    );
  }

  Widget _txtPasswordNueva() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: passwordNuevaCtrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Nueva Contraseña ',
          suffixIcon: Icon(FontAwesomeIcons.key),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          if (value.length < 8) {
            return 'La contraseña debe tener mínimo 8 caracteres';
          }

          return null;
        },
      ),
    );
  }

  Widget _txtPassword2() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: passwordNueva2Ctrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Repetir Nueva Contraseña',
          suffixIcon: Icon(FontAwesomeIcons.key),
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          if (value != passwordCtrl.text) {
            return 'Las contraseñas no coinciden';
          }

          return null;
        },
      ),
    );
  }

  Widget _txtNombre() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: nombreCtrl,
        keyboardType: TextInputType.name,
        decoration: InputDecoration(
          labelText: 'Nombre',
          suffixIcon: Icon(FontAwesomeIcons.user),
        ),
      ),
    );
  }

  Widget _txtApellidoPaterno() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: apellidoPaternoCtrl,
        decoration: InputDecoration(
          labelText: 'Apellido Paterno',
          suffixIcon: Icon(FontAwesomeIcons.idCard),
        ),
      ),
    );
  }

  Widget _txtApellidoMaterno() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: apellidoMaternoCtrl,
        decoration: InputDecoration(
          labelText: 'Apellido Materno',
          suffixIcon: Icon(FontAwesomeIcons.idCard),
        ),
      ),
    );
  }

  Widget _txtFechaNacimiento(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        enableInteractiveSelection: false,
        controller: fechaNacimientoCtrl,
        decoration: InputDecoration(
          hintText: 'Fecha Nacimiento',
          labelText: 'Fecha Nacimiento',
          suffixIcon: Icon(FontAwesomeIcons.calendarDay),
        ),
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
          _selectDate(context);
        },
      ),
    );
  }

  _selectDate(BuildContext context) async {
    DateTime picked = await showDatePicker(
      context: context,
      initialDate: new DateTime.now(),
      firstDate: new DateTime(2018),
      lastDate: new DateTime.now(),
      locale: Locale('es', 'ES'),
    );

    if (picked != null) {
      setState(() {
        fechaNacimientoCtrl.text = DateFormat('dd-MM-yyyy').format(picked);
      });
    }
  }

  Widget _txtNumeroCelular() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: celularCtrl,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          labelText: 'Numero de Celular(+56)',
          suffixIcon: Icon(FontAwesomeIcons.phone),
        ),
      ),
    );
  }

  Widget _txtSexo() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: DropdownButton<String>(
        isExpanded: true,
        hint: Text('Sexo'),
        items: _sexo.map((String dropDownStringItem) {
          return DropdownMenuItem(
            value: dropDownStringItem,
            child: Text(dropDownStringItem),
          );
        }).toList(),
        onChanged: (valueSelect) {
          setState(() {
            this._sexoItemSelected = valueSelect;
          });
        },
        value: _sexoItemSelected,
      ),
    );
  }

  Widget _txtPerfil() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: DropdownButton<String>(
        isExpanded: true,
        hint: Text('Perfil'),
        items: _perfil.map((String dropDownStringItem) {
          return DropdownMenuItem(
            value: dropDownStringItem,
            child: Text(dropDownStringItem),
          );
        }).toList(),
        onChanged: (valueSelect) {
          setState(() {
            this._perfilItemSelected = valueSelect;
          });
        },
        value: _perfilItemSelected,
      ),
    );
  }

  Widget _txtProfesion() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: profesionCtrl,
        decoration: InputDecoration(
          labelText: 'Profesión',
          suffixIcon: Icon(FontAwesomeIcons.userTie),
        ),
      ),
    );
  }

  Widget _btnGuardar() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: ElevatedButton(
          child: Text('Guardar Datos'),
          onPressed: () {
            if (_formKey.currentState.validate()) {
              FocusScope.of(context).unfocus();

              // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              //     backgroundColor: ThemeData().primaryColor,
              //     content: Text('Processing Data')));
            }
          },
        ),
      ),
    );
  }
}
