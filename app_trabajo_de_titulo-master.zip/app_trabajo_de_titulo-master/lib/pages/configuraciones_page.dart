import 'package:flutter/material.dart';

class ConfiguracionesPage extends StatefulWidget {
  ConfiguracionesPage({Key key}) : super(key: key);

  @override
  _ConfiguracionesPageState createState() => _ConfiguracionesPageState();
}

class _ConfiguracionesPageState extends State<ConfiguracionesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Configuraciones'),
      ),
      body: Container(
        child: Text('Configuraciones'),
      ),
    );
  }
}
