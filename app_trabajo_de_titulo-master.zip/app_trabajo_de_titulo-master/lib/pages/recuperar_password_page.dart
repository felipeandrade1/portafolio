import 'package:flutter/material.dart';

class RecuperarPasswordPage extends StatefulWidget {
  RecuperarPasswordPage({Key key}) : super(key: key);

  @override
  _RecuperarPasswordPageState createState() => _RecuperarPasswordPageState();
}

class _RecuperarPasswordPageState extends State<RecuperarPasswordPage> {
  TextEditingController emailCtrl = TextEditingController();
  String mensajeLogin = '';

  final _formKey = GlobalKey<FormState>();
  final _emailRegex =
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Recuperar Contraseña'),
      ),
      body: Form(
        key: _formKey,
        child: GestureDetector(
          onTap: () {
            final FocusScopeNode focus = FocusScope.of(context);
            if (!focus.hasPrimaryFocus && focus.hasFocus) {
              FocusManager.instance.primaryFocus.unfocus();
            }
          },
          child: ListView(
            children: <Widget>[
              _txtEmail(),
              _btnLogin(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _txtEmail() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: emailCtrl,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          labelText: 'Email',
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'Indique Email';
          }
          if (!RegExp(_emailRegex).hasMatch(value)) {
            return 'Email no válido';
          }
          return null;
        },
      ),
    );
  }

  Widget _btnLogin() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: ElevatedButton(
          child: Text(
            'Recuperar Contraseña',
            style: TextStyle(color: Colors.white),
          ),
          onPressed: () {
            if (_formKey.currentState.validate()) {}
            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            //     backgroundColor: ThemeData().primaryColor,
            //     content: Text('Verificando Datos')));
            // _login();
          },
        ),
      ),
    );
  }
}
