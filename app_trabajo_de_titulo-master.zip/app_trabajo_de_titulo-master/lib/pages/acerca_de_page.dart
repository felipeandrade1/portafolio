import 'package:flutter/material.dart';

class AcercaDePage extends StatefulWidget {
  AcercaDePage({Key key}) : super(key: key);

  @override
  _AcercaDePageState createState() => _AcercaDePageState();
}

class _AcercaDePageState extends State<AcercaDePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Acerca de...'),
      ),
      body: Container(
        child: Text('Acerca de...'),
      ),
    );
  }
}
