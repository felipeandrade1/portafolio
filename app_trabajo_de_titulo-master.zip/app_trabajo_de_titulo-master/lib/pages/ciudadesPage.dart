import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/material.dart';

class CiudadesPage extends StatefulWidget {
  CiudadesPage({Key key}) : super(key: key);

  @override
  _CiudadesPageState createState() => _CiudadesPageState();
}

class _CiudadesPageState extends State<CiudadesPage> {
  VelocistasService velocistas = new VelocistasService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ciudades'),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
              child: Text('Lista de Ciudades'),
            ),
            Expanded(
              child: FutureBuilder(
                future: velocistas.obtenerDato('ciudades'),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return ListView.separated(
                      separatorBuilder: (context, index) => Divider(),
                      itemCount: snapshot.data.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(snapshot.data[index]['nombre']),
                          subtitle:
                              Text('Pais: ${snapshot.data[index]['pais']}'),
                        );
                      },
                    );
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  child: Text('Nueva Ciudad'),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
