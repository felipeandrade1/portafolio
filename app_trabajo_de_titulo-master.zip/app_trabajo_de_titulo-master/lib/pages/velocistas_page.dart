import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/material.dart';

class VelocistasPage extends StatefulWidget {
  VelocistasPage({Key key}) : super(key: key);

  @override
  _VelocistasPageState createState() => _VelocistasPageState();
}

class _VelocistasPageState extends State<VelocistasPage> {
  VelocistasService velocistas = new VelocistasService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Velocistas'),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
              child: Text('Lista de Velocistas'),
            ),
            Expanded(
              child: FutureBuilder(
                future: velocistas.obtenerDato('velocistas'),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return ListView.separated(
                        separatorBuilder: (context, index) => Divider(),
                        itemCount: snapshot.data.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(snapshot.data[index]['nombre']),
                            subtitle: Row(
                              children: [
                                Text(
                                    'Nivel Fisico: ${snapshot.data[index]['nivel_fisico']}'),
                                Text(
                                    'Nivel Fisico: ${snapshot.data[index]['nivel_fisico']}'),
                                Text(
                                    'Nivel Fisico: ${snapshot.data[index]['nivel_fisico']}'),
                              ],
                            ),
                            trailing: Text(
                                'Altitud: ${snapshot.data[index]['altitud']}m'),
                          );
                        });
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  child: Text('Nuevo Velocista'),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
