import 'package:app_trabajo_de_titulo/pages/home_page.dart';
import 'package:app_trabajo_de_titulo/pages/registrar_usuario_page.dart';
import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  LoginPage({Key key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController passwordCtrl = TextEditingController();
  String mensajeLogin = '';

  final _formKey = GlobalKey<FormState>();
  final _emailRegex =
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Iniciar Sesión'),
      ),
      body: Form(
        key: _formKey,
        child: GestureDetector(
          onTap: () {
            final FocusScopeNode focus = FocusScope.of(context);
            if (!focus.hasPrimaryFocus && focus.hasFocus) {
              FocusManager.instance.primaryFocus.unfocus();
            }
          },
          child: ListView(
            children: <Widget>[
              _txtEmail(),
              _txtPassword(),
              Container(
                  margin: EdgeInsets.only(top: 10.0),
                  alignment: Alignment.center,
                  child: Text(
                    mensajeLogin,
                    style: TextStyle(color: Colors.red),
                  )),
              _btnLogin(),
              Container(
                child: TextButton(
                  child: Text(
                    'Crear Cuenta',
                    style: TextStyle(decoration: TextDecoration.underline),
                  ),
                  onPressed: () {
                    final route = MaterialPageRoute(
                        builder: (context) => RegistrarUsuarioPage());
                    Navigator.push(context, route);
                  },
                ),
              ),
              // Container(
              //   child: TextButton(
              //     child: Text(
              //       '¿Has olvidado la contraseña?',
              //       style: TextStyle(decoration: TextDecoration.underline),
              //     ),
              //     onPressed: () {
              //       final route = MaterialPageRoute(
              //           builder: (context) => RecuperarPasswordPage());
              //       Navigator.push(context, route);
              //     },
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _txtEmail() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: emailCtrl,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          labelText: 'Correo',
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'Indique Correo';
          }
          if (!RegExp(_emailRegex).hasMatch(value)) {
            return 'Correo no válido';
          }
          return null;
        },
      ),
    );
  }

  Widget _txtPassword() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: passwordCtrl,
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Contraseña',
        ),
        validator: (value) {
          if (value.isEmpty) {
            return 'indique Contraseña';
          }
          return null;
        },
      ),
    );
  }

  Widget _btnLogin() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: ElevatedButton(
          child: Text(
            'INICIAR SESIÓN',
            style: TextStyle(color: Colors.white),
          ),
          onPressed: () {
            if (_formKey.currentState.validate()) {
              _login();
            }
            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            //     backgroundColor: ThemeData().primaryColor,
            //     content: Text('Verificando Datos')));
          },
        ),
      ),
    );
  }

  _login() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var velocistasService = new VelocistasService();
    var respuesta = await velocistasService.login(
      emailCtrl.text.trim(),
      passwordCtrl.text.trim(),
    );
    if (respuesta == null) {
      setState(() {
        mensajeLogin = 'Error de conexión';
      });
    } else if (respuesta['access_token'] == null) {
      setState(() {
        mensajeLogin = respuesta['message'];
      });
    } else {
      sharedPreferences.setString('token', respuesta['access_token']);
      print(sharedPreferences.get('token'));
      final route = MaterialPageRoute(builder: (context) {
        return HomePage();
      });
      Navigator.pushReplacement(context, route);
    }
  }
}
