import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/material.dart';

class EquiposPage extends StatefulWidget {
  EquiposPage({Key key}) : super(key: key);

  @override
  _EquiposPageState createState() => _EquiposPageState();
}

class _EquiposPageState extends State<EquiposPage> {
  VelocistasService velocistas = new VelocistasService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Equipos'),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
              child: Text('Lista de Equipos'),
            ),
            Expanded(
              child: FutureBuilder(
                future: velocistas.obtenerDato('equipos'),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return ListView.separated(
                      separatorBuilder: (context, index) => Divider(),
                      itemCount: snapshot.data.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(snapshot.data[index]['nombre']),
                          trailing: Icon(Icons.arrow_forward_ios_rounded),
                        );
                      },
                    );
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  child: Text('Nuevo Equipo'),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
