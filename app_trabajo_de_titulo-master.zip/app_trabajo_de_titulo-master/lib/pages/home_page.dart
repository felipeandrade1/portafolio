import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:app_trabajo_de_titulo/pages/acerca_de_page.dart';
import 'package:app_trabajo_de_titulo/pages/carreras_page.dart';
import 'package:app_trabajo_de_titulo/pages/carreras_realizadas_page.dart';
import 'package:app_trabajo_de_titulo/pages/categorias_page.dart';
import 'package:app_trabajo_de_titulo/pages/ciudadesPage.dart';
import 'package:app_trabajo_de_titulo/pages/configuraciones_page.dart';
import 'package:app_trabajo_de_titulo/pages/equipos_page.dart';
import 'package:app_trabajo_de_titulo/pages/login_page.dart';
import 'package:app_trabajo_de_titulo/pages/perfil_page.dart';
import 'package:app_trabajo_de_titulo/pages/velocistas_page.dart';

class HomePage extends StatefulWidget {
  HomePage({Key key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Inicio'),
          actions: <Widget>[
            IconButton(
                icon: Icon(Icons.exit_to_app_rounded),
                onPressed: () => _logout(context))
          ],
        ),
        drawer: Drawer(
          child: ListView(
            children: <Widget>[
              DrawerHeader(
                child: Column(
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage('assets/images/user-masculino.png'),
                        ),
                        border: Border.all(
                          width: 2.0,
                          color: ThemeData().primaryColor,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Text('', style: TextStyle(fontSize: 18)),
                    )
                  ],
                ),
              ),
              ListTile(
                title: Text('Mi Perfil'),
                leading: Icon(
                  Icons.person,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 1),
              ),
              Divider(),
              ListTile(
                title: Text('Mis Carreras'),
                leading: Icon(
                  Icons.directions_run,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 2),
              ),
              Divider(),
              ListTile(
                title: Text('Mis Carreras Realizadas'),
                leading: Icon(
                  Icons.flag_outlined,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 3),
              ),
              Divider(),
              ListTile(
                title: Text('Categorias'),
                leading: Icon(
                  Icons.category,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 4),
              ),
              Divider(),
              ListTile(
                title: Text('Ciudades'),
                leading: Icon(
                  Icons.location_on,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 5),
              ),
              Divider(),
              ListTile(
                title: Text('Mis Equipos'),
                leading: Icon(
                  FontAwesomeIcons.users,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 6),
              ),
              Divider(),
              ListTile(
                title: Text('Velocistas'),
                leading: Icon(
                  FontAwesomeIcons.running,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 7),
              ),
              Divider(),
              ListTile(
                title: Text('Configuraciones'),
                leading: Icon(
                  Icons.settings,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 8),
              ),
              Divider(),
              ListTile(
                title: Text('Acerca de...'),
                leading: Icon(
                  FontAwesomeIcons.infoCircle,
                  color: ThemeData().primaryColor,
                ),
                onTap: () => _navegar(context, 9),
              ),
              Divider(),
              ListTile(
                  title: Text('cerrar'),
                  leading: Icon(
                    FontAwesomeIcons.arrowLeft,
                    color: ThemeData().primaryColor,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  }),
              Divider(),
            ],
          ),
        ),
        body: GridView.count(
          primary: false,
          padding: const EdgeInsets.all(20),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          crossAxisCount: 2,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(8),
              child: Text(""),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
            Container(
              padding: const EdgeInsets.all(8),
              child: const Text(''),
              color: ThemeData().primaryColor,
            ),
          ],
        ));
  }

  _logout(BuildContext context) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.remove('token');
    final route = MaterialPageRoute(builder: (context) {
      return LoginPage();
    });
    Navigator.pushReplacement(context, route);
  }

  void _navegar(BuildContext context, int pagina) {
    List<Widget> paginas = [
      PerfilPage(),
      CarrerasPage(),
      CarrerasRealizadasPage(),
      CategoriasPage(),
      CiudadesPage(),
      EquiposPage(),
      VelocistasPage(),
      ConfiguracionesPage(),
      AcercaDePage(),
    ];
    final route = MaterialPageRoute(builder: (context) {
      return paginas[pagina - 1];
    });
    Navigator.pop(context);
    Navigator.push(context, route);
  }
}
