import 'package:flutter/material.dart';

class CarrerasRealizadasPage extends StatefulWidget {
  CarrerasRealizadasPage({Key key}) : super(key: key);

  @override
  _CarrerasRealizadasPageState createState() => _CarrerasRealizadasPageState();
}

class _CarrerasRealizadasPageState extends State<CarrerasRealizadasPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Carreras Realizadas'),
      ),
      body: Container(
        child: Text('Carreras Realizadas'),
      ),
    );
  }
}
