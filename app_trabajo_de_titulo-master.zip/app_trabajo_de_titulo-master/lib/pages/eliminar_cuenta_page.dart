import 'package:flutter/material.dart';

class EliminarCuentaPage extends StatefulWidget {
  EliminarCuentaPage({Key key}) : super(key: key);

  @override
  _EliminarCuentaPageState createState() => _EliminarCuentaPageState();
}

class _EliminarCuentaPageState extends State<EliminarCuentaPage> {
  TextEditingController eliminarCuentaCtrl = TextEditingController();

  bool _eliminarCuenta;

  @override
  void initState() {
    _eliminarCuenta = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Eliminar Cuenta'),
      ),
      body: ListView(
        children: [
          _eliminarCuentaSwitch(),
          _btnGuardar(),
        ],
      ),
    );
  }

  Widget _eliminarCuentaSwitch() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: SwitchListTile(
          value: _eliminarCuenta,
          title: Text('¿Desea eliminar su cuenta?'),
          onChanged: (valor) {
            setState(() {
              _eliminarCuenta = valor;
            });
          }),
    );
  }

  Widget _btnGuardar() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
          ),
          child: Text('Eliminar Cuenta'),
          onPressed: () {
            // if (_formKey.currentState.validate()) {
            //   FocusScope.of(context).unfocus();

            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            //     backgroundColor: ThemeData().primaryColor,
            //     content: Text('Processing Data')));
            // }

            if (_eliminarCuenta == true) {}
          },
        ),
      ),
    );
  }
}
