import 'package:flutter/material.dart';

class RegistarVelocistasPage extends StatefulWidget {
  RegistarVelocistasPage({Key key}) : super(key: key);

  @override
  _RegistarVelocistasPageState createState() => _RegistarVelocistasPageState();
}

class _RegistarVelocistasPageState extends State<RegistarVelocistasPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registrar Velocista'),
      ),
      body: ListView(
        children: [],
      ),
    );
  }
}
