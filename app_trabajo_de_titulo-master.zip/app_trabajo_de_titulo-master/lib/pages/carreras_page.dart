import 'package:app_trabajo_de_titulo/services/VelocistasService.dart';
import 'package:flutter/material.dart';

class CarrerasPage extends StatefulWidget {
  CarrerasPage({Key key}) : super(key: key);

  @override
  _CarrerasPageState createState() => _CarrerasPageState();
}

class _CarrerasPageState extends State<CarrerasPage> {
  VelocistasService velocistas = new VelocistasService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Carreras'),
      ),
      body: Center(
        child: Column(
          children: [
            Container(
              child: Text('Lista de Carreras'),
            ),
            Expanded(
              child: FutureBuilder(
                future: velocistas.obtenerDato('carreras'),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return ListView.separated(
                        separatorBuilder: (context, index) => Divider(),
                        itemCount: snapshot.data.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(snapshot.data[index]['nombre']),
                            subtitle:
                                Text('Fecha: ${snapshot.data[index]['fecha']}'),
                            trailing: Text(
                                'Altitud: ${snapshot.data[index]['altitud']}m'),
                          );
                        });
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: double.infinity,
                height: 40,
                child: ElevatedButton(
                  child: Text('Nueva Carrera'),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
