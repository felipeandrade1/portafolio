import 'dart:collection';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class VelocistasService {
  final apiUrl = 'http://10.0.2.2:8000/api/';
  // final apiUrl = 'http://192.168.8.111:8000/api/';
  // final apiUrl = 'http://127.0.0.1:8000/api/';

  Future<List<dynamic>> obtenerDato(String path) async {
    // var url = Uri.parse(apiUrl + path);
    // var response = await http.get(url);

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var token = 'Bearer ' + sharedPreferences.getString('token');
    var response = await http
        .get(Uri.parse(apiUrl + path), headers: {'Authorization': token});
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      // throw Exception('Falló la conexión');
      return null;
    }
  }

  // Future<List<dynamic>> obtenerDato() async {
  //   var url = Uri.parse(apiUrl);
  //   var response = await http.get(url);
  //   if (response.statusCode == 200) {
  //     return json.decode(response.body);
  //   } else {
  //     return [];
  //   }
  // }

  Future<LinkedHashMap<String, dynamic>> login(
      String email, String password) async {
    var urlRequest = apiUrl + 'usuarios/login';
    var response = await http.post(
      Uri.parse(urlRequest),
      headers: <String, String>{
        'Content-Type': 'aplication/json; charset=UTF-8'
      },
      body: jsonEncode(<String, String>{'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      return null;
    }
  }

  Future<http.Response> usuarioAgregar(
      String email,
      String password,
      String nombre,
      String apellidoPaterno,
      String apellidoMaterno,
      String fechaNacimiento,
      String celular,
      String sexo,
      String perfil,
      String profesion) async {
    var urlRequest = apiUrl + 'users';
    var respuesta = await http.post(
      Uri.parse(urlRequest),
      headers: <String, String>{
        'Content-Type': 'aplication/json; charset=UTF-8'
      },
      body: jsonEncode(<String, String>{
        'email': email,
        'password': password,
        'nombre': nombre,
        'apellido_paterno': apellidoPaterno,
        'apellido_materno': apellidoMaterno,
        'fecha_nacimiento': fechaNacimiento,
        'celular': celular,
        'sexo': sexo,
        'perfil': perfil,
        'profesion': profesion,
      }),
    );
    return respuesta;
  }

  Future<http.Response> usuarioEditar(
      int idUsuario,
      String email,
      String password,
      String nombre,
      String apellidoPaterno,
      String apellidoMaterno,
      String fechaNacimiento,
      String celular,
      String sexo,
      String perfil,
      String profesion) async {
    var urlRequest = apiUrl + 'users/' + idUsuario.toString();
    var respuesta = await http.put(
      Uri.parse(urlRequest),
      headers: <String, String>{
        'Content-Type': 'aplication/json; charset=UTF-8'
      },
      body: jsonEncode(<String, String>{
        'email': email,
        'password': password,
        'nombre': nombre,
        'apellido_paterno': apellidoPaterno,
        'apellido_materno': apellidoMaterno,
        'fecha_nacimiento': fechaNacimiento,
        'celular': celular,
        'sexo': sexo,
        'perfil': perfil,
        'profesion': profesion,
      }),
    );
    return respuesta;
  }

  Future<http.Response> usuarioBorrar(int id) async {
    var urlRequest = apiUrl + 'users/' + id.toString();
    var respuesta = await http.delete(Uri.parse(urlRequest));
    return respuesta;
  }
}
